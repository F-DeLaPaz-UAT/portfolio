TinkerCode (Windows x64)
Compress-Archive -Path .\dist\* -DestinationPath .\tinkercode-win64.zip -Force
